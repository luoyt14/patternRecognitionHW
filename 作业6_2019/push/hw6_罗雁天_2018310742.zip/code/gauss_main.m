clear
clc
close all


w1 = [2,0;2,2;2,4;3,3];
w2 = [0,3;-2,2;-1,-1;1,-2;3,-1];
Bayes_Gauss(w1, w2);