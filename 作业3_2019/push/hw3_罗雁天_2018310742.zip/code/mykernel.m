function zz = mykernel(x,y)
    zz = ((x-2).^2+(y-2).^2-1).^2;
%     zz = ((x-2).^2-(y-2).^2).^2;
end

